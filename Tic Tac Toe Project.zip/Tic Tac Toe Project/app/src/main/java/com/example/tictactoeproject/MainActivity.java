package com.example.tictactoeproject;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int[][] board = {{-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Switch swtStarts = (Switch)findViewById(R.id.swtStarts);
        final TextView lblResult = (TextView)findViewById(R.id.lblResult);
        final Button btn00 = (Button)findViewById(R.id.btn00);
        final Button btn01 = (Button)findViewById(R.id.btn01);
        final Button btn02 = (Button)findViewById(R.id.btn02);
        final Button btn10 = (Button)findViewById(R.id.btn10);
        final Button btn11 = (Button)findViewById(R.id.btn11);
        final Button btn12 = (Button)findViewById(R.id.btn12);
        final Button btn20 = (Button)findViewById(R.id.btn20);
        final Button btn21 = (Button)findViewById(R.id.btn21);
        final Button btn22 = (Button)findViewById(R.id.btn22);
        Button[][] squares = {{btn00, btn01, btn02}, {btn10, btn11, btn12}, {btn20, btn21, btn22}};
        final Button btnRestart = (Button)findViewById(R.id.btnReset);

        boolean[] turn = {true};



        for (int o = 0; o <= squares.length - 1; o++)
        {
            for (int i = 0; i <= squares[o].length - 1; i++)
            {
                final int row = o;
                final int col = i;
                squares[row][col].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (turn[0]) {
                            board[row][col] = 1;
                            squares[row][col].setText("X");
                            squares[row][col].setClickable(false);
                            turn[0] = false;
                            CheckWin(board, row, col, "X", swtStarts.isChecked(), squares);
                        }
                        else {
                            board[row][col] = 0;
                            squares[row][col].setText("O");
                            squares[row][col].setClickable(false);
                            turn[0] = true;
                            CheckWin(board, row, col, "O", swtStarts.isChecked(), squares);
                        }
                    }
                });
            }
        }

        btnRestart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                board = new int[][] {{-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}};
                turn[0] = true;

                for (int o = 0; o <= squares.length - 1; o++)
                {
                    for(int i = 0; i <= squares[o].length - 1; i++)
                    {
                        squares[o][i].setText("");
                        squares[o][i].setClickable(true);
                    }
                }

                lblResult.setText("");
            }
        });
    }

    public void CheckWin(int[][] board, int pos1, int pos2, String turn, boolean swtChecked, Button[][] squares)
    {
        final TextView lblResult = (TextView)findViewById(R.id.lblResult);

        boolean win = false;

        if (board[pos1][0] == board[pos1][1] && board[pos1][0] == board[pos1][2] ||
            board[0][pos2] == board[1][pos2] && board[0][pos2] == board[2][pos2])
            win = true;
        else if (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board[0][0] != -1||
                 board[0][2] == board[1][1] && board[0][2] == board[2][0] && board[0][2] != -1)
            win = true;

        if (win)
        {
            int winner;
            if (turn.equals("X"))
            {
                if (swtChecked)
                    winner = 2;
                else
                    winner = 1;
            }
            else if (turn.equals("O") && swtChecked)
                winner = 1;
            else
                winner = 2;

            Win(winner, squares);
        }
        else
        {
            boolean tie = true;
            for (int o = 0; o <= board.length - 1; o++)
            {
                for(int i = 0; i <= board[o].length - 1; i++)
                {
                    if (board[o][i] == -1)
                    {
                        tie = false;
                        break;
                    }
                }
                if (!tie)
                    break;
            }

            if (tie)
                lblResult.setText("Tie Game");
        }


    }

    public void Win(int winner, Button[][] buttons)
    {
        final TextView lblP1Score = (TextView)findViewById(R.id.lblP1Score);
        String P1ScoreText = lblP1Score.getText().toString();
        final TextView lblP2Score = (TextView)findViewById(R.id.lblP2Score);
        String P2ScoreText = lblP2Score.getText().toString();
        final TextView lblResult = (TextView)findViewById(R.id.lblResult);

        if (winner == 1)
        {
            int lastSpaceIndex = P1ScoreText.lastIndexOf(" ");
            int p1Score = Integer.parseInt(P1ScoreText.substring(lastSpaceIndex + 1));
            p1Score++;
            lblP1Score.setText(P1ScoreText.substring(0, lastSpaceIndex + 1) + p1Score);
            lblResult.setText("Player 1 Wins!");
        }
        else
        {
            int lastSpaceIndex = P2ScoreText.lastIndexOf(" ");
            int p2Score = Integer.parseInt(P2ScoreText.substring(lastSpaceIndex + 1));
            p2Score++;
            lblP2Score.setText(P2ScoreText.substring(0, lastSpaceIndex + 1) + p2Score);
            lblResult.setText("Player 2 Wins!");
        }

        for (int o = 0; o <= buttons.length - 1; o++)
        {
            for(int i = 0; i <= buttons[o].length - 1; i++)
            {
                buttons[o][i].setClickable(false);
            }
        }

    }
}